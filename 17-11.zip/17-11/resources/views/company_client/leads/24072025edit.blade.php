@extends('layouts.client')

@section('title', 'Edit Lead')

@section('content')


    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                {{-- Alert Messages --}}
                @include('common.alert')

                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0">Edit Lead</h4>
                            <div class="page-title-right">
                                <a href="{{ route('leads.index') }}"
                                    class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                    Back
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="live-preview">

                                    <form action="{{ route('leads.update', $lead->lead_id) }}" method="POST">
                                        @csrf
                                        @method('PUT')
                                        <div class="row gy-4">
                                            @include('company_client.leads.form', ['lead' => $lead])
                                        </div>
                                        <div class="card-footer mt-2">
                                            <div class="mb-3" style="float: right;">
                                                <button type="submit"
                                                    class="btn btn-primary btn-user float-right mb-3 mx-2">Update</button>
                                                <a class="btn btn-primary float-right mr-3 mb-3 mx-2"
                                                    href="{{ route('leads.index') }}">Cancel</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script>
        flatpickr("#followup_datetime", {
            enableTime: true,
            dateFormat: "d-m-Y h:i K",
            time_24hr: false
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const initially_contacted = document.getElementById('initially_contacted');
            const pipeline_status = document.getElementById('pipeline_statusDiv');
            const commentDiv = document.getElementById('commentDiv');
            const followUpBox = document.getElementById('follow_up_dateBox');
            const statusSelect = document.getElementById('pipeline_status');
            const commentSelect = document.getElementById('comment');
            const amountSelect = document.getElementById('Amount');
            const followup_datetimeSelect = document.getElementById('followup_datetime');
            const cancelReasonBox = document.getElementById('cancelReasonBox');
            const amountBox = document.getElementById('amountBox');
            const cancel_reason_idBox = document.getElementById('cancel_reason_id');

            function initiallyContacted() {
                const initially_contactedValue = initially_contacted.value;

                if (initially_contactedValue === 'Yes') {
                    pipeline_status.style.display = 'block';
                    statusSelect.setAttribute('required', 'required');
                    commentDiv.style.display = 'block';
                    commentSelect.setAttribute('required', 'required');
                } else {
                    pipeline_status.style.display = 'none';
                    statusSelect.removeAttribute('required');
                    commentDiv.style.display = 'none';
                    commentSelect.removeAttribute('required');

                    // Reset dependent fields
                    cancelReasonBox.style.display = 'none';
                    followUpBox.style.display = 'none';
                    amountBox.style.display = 'none';
                }
            }

            function toggleFields() {
                const selectedOption = statusSelect.options[statusSelect.selectedIndex];
                if (!selectedOption) return;

                const selectedText = selectedOption.text;
                const followupNeeded = selectedOption.getAttribute('data-followup');
                const initially_contactedValue = initially_contacted.value;

                // Reset
                amountBox.style.display = 'none';
                cancelReasonBox.style.display = 'none';
                followUpBox.style.display = 'none';

                amountSelect.removeAttribute('required');
                cancel_reason_idBox.removeAttribute('required');
                followup_datetimeSelect.removeAttribute('required');

                if (initially_contactedValue !== 'Yes') {
                    return; // ⛔ Stop here if 'No'
                }

                if (selectedText === 'Deal Done') {
                    amountBox.style.display = 'block';
                    amountSelect.setAttribute('required', 'required');
                } else if (selectedText === 'Deal Cancel') {
                    cancelReasonBox.style.display = 'block';
                    cancel_reason_idBox.setAttribute('required', 'required');
                }

                if (selectedText === 'Deal Pending' || followupNeeded === 'yes') {
                    followUpBox.style.display = 'block';
                    followup_datetimeSelect.setAttribute('required', 'required');
                }
            }


            // Attach listeners
            initially_contacted.addEventListener('change', function() {
                initiallyContacted();
                toggleFields();
            });

            statusSelect.addEventListener('change', toggleFields);

            // Run once on load
            initiallyContacted();

            // Only run toggleFields if status has a value
            if (statusSelect.value) {
                toggleFields();
            }
        });
    </script>

@endsection
