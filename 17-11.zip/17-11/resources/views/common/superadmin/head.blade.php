<head>

    <meta charset="utf-8" />

    <title>{{ env('APP_NAME') }} | @yield('title')</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta content="Themesbrand" name="author" />

    <!-- App favicon -->

    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.png')}}">



    <!-- Layout config Js -->

    <script src="{{ asset('assets/js/layout.js') }}"></script>

    <!-- Bootstrap Css -->

    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />

    <!-- Icons Css -->

    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />

    <!-- App Css-->

    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" />

    <!-- custom Css-->

    <link href="{{ asset('assets/css/custom.min.css') }}" rel="stylesheet" type="text/css" />





    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"

        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="

        crossorigin="anonymous" referrerpolicy="no-referrer" />



</head>


