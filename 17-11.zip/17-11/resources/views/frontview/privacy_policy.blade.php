@extends('layouts.front')
@section('title', 'Privacy Policy')
@section('content')

    <body class="terms-page">
        <!-- Page hero -->
        <header class="page-hero">
            <div class="container">
                <span class="kicker">Legal</span>
                <h1 class="display-6 fw-bold mt-2 mb-1">Privacy Policy</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('front.index') }}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                    </ol>
                </nav>
            </div>
        </header>

        <!-- Terms content -->
        <main class="terms-wrap">
            <div class="container">
                <div class="terms-card">
                    <h2 class="h4">Privacy Policy</h2>
                    <p>
                        Smaart CRM Company is committed to protecting your privacy. This Privacy Policy explains how we
                        collect, use,
                        store, and share your information when you use our mobile application, Lead Management Software,
                        available on
                        Android devices via the Google Play Store.
                    </p>
                    <p>
                        By installing, registering with, accessing, or using the app, you consent to the practices described
                        in this
                        Privacy Policy.
                    </p>

                    <h2 class="section-title">1. Data We Collect</h2>

                    <h5>A. User Profile Data</h5>
                    <ul>
                        <li> Full Name</li>
                        <li> Email Address</li>
                        <li> Mobile Number</li>
                        <li> Encrypted Password</li>
                    </ul>

                    <h5>B. Lead Information</h5>
                    <ul>
                        <li> Company Name</li>
                        <li> GST Number</li>
                        <li> Mobile Number</li>
                        <li> Contact Person Name</li>
                        <li> Notes or Tags</li>
                    </ul>

                    <h5>C. Device & Usage Data</h5>
                    <ul>
                        <li> IP address, device ID, OS version</li>
                        <li> App usage logs, crashes, and diagnostics</li>
                        <li> Mobile network information</li>
                    </ul>

                    <h2 class="section-title">2. How We Use Your Data</h2>
                    <ul>
                        <li>Provide core app features (lead creation, management, reports)</li>
                        <li>Manage user accounts and logins</li>
                        <li>Send important service communications (e.g., lead updates, alerts)</li>
                        <li>Analyze usage patterns to improve app performance</li>
                        <li>Store your data with reliable third-party cloud providers</li>
                    </ul>

                    <h2 class="section-title">3. Third-Party Services</h2>
                    <p>We may use third-party services (e.g., AWS, Firebase, MongoDB Atlas) to:</p>
                    <ul>
                        <li>Host and store your data</li>
                        <li>Send notifications or emails</li>
                        <li>Perform analytics</li>
                    </ul>
                    <p>These third-party services may access your data as required to perform their functions but are
                        obligated not to
                        disclose or use it for other purposes.</p>

                    <h2 class="section-title">4. Data Sharing</h2>
                    <ul>
                        <li>With third-party infrastructure providers for storage, hosting, or backup</li>
                        <li>With law enforcement or authorities, if legally required</li>
                        <li>In the event of a business merger, sale, or acquisition (with notice)</li>
                    </ul>

                    <h2 class="section-title">5. Data Retention & Deletion</h2>
                    <p>Your data is retained:</p>
                    <ul>
                        <li>As long as your account is active</li>
                        <li>As needed for compliance or dispute resolution</li>
                    </ul>
                    <p>You may request deletion of your data by contacting us at <a
                            href="mailto:info@smaartcrm.in">info@smaartcrm.in</a>.</p>

                    <h2 class="section-title">6. Data Security & Limitation of Liability</h2>
                    <p>We implement security measures such as:</p>
                    <ul>
                        <li>Encryption of sensitive data</li>
                        <li>Access control to servers</li>
                        <li>Regular backups</li>
                    </ul>
                    <p><strong>⚠️ Disclaimer:</strong> Smaart CRM is not liable for any data loss, breach, or unauthorized
                        access
                        resulting from third-party service failures, device misuse, or force majeure events.</p>

                    <h2 class="section-title">7. User Responsibilities</h2>
                    <ul>
                        <li>Keeping your login credentials confidential</li>
                        <li>Ensuring correct data entry</li>
                        <li>Not sharing your account access with others</li>
                    </ul>

                    <h2 class="section-title">8. Children’s Privacy</h2>
                    <p>Our app is not intended for children under 13. We do not knowingly collect data from children. If you
                        believe a
                        child has used the app, contact us to delete their data.</p>

                    <h2 class="section-title">9. International Users</h2>
                    <p>While the app is operated from India, your data may be stored on servers located in other countries.
                        By using
                        the app, you consent to such cross-border transfers.</p>

                    <h2 class="section-title">10. Changes to This Policy</h2>
                    <p>We may update this Privacy Policy from time to time. We will notify you via app notification or
                        update log.
                        Continued use of the app after changes implies acceptance.</p>

                    <h2 class="section-title">11. Contact Us</h2>
                    <ul>
                        <li><i class="fas fa-envelope me-1"></i> Email: <a
                                href="mailto:info@smaartcrm.in">info@smaartcrm.in</a></li>
                        <li><i class="fas fa-globe me-1"></i> Website: <a href="https://smaartcrm.in"
                                target="_blank">https://smaartcrm.in</a></li>
                        <li><i class="fas fa-map-marker-alt me-1"></i> Address: 1, Anurag Flats, Bhairav Nath Cross Road,
                            Maninagar,
                            Ahmedabad, Gujarat – 380008, India</li>
                    </ul>
                </div>
            </div>
        </main>
    </body>


@endsection
