<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Salexo—CRM | Best CRM toll to manage Sales,leads and lead followups. </title>
    <meta name="description"
        content="Salexo is a cloud-based CRM that captures leads, automates follow-ups, and converts prospects into customers." />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet" />

    <link rel="stylesheet" href="{{ asset('assets/front/css/style.css') }}">
</head>
